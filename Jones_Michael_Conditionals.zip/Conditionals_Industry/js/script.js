//Michael Jones
//August 21, 2014
//Assignment: Conditionals - Industry

//Work Force Digital ID For Workers
var Firstname = prompt("Please enter First name");
var Lastname = prompt("Please enter Last Name");
var number = prompt("Please enter your unique number for ID"); // this number will be assigned to the employee name.
if(answer = Firstname + Lastname + number){
    //print employee unique ID
    console.log(answer);
}